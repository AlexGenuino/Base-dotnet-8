﻿namespace Domain.Enum
{
    public enum StatusItem
    {
        Active = 1, //Ativo
        Filled = 2 //Arquivado
    }
}

﻿namespace Domain.Enum
{
    public enum StatusCard
    {
        Todo = 1, //A fazer
        Done = 2, //Pronto
        Late = 3, //Atrasado
        NoStatus = 4 //Sem Status
    }
}
